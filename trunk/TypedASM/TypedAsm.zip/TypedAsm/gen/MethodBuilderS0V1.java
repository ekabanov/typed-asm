
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

public class MethodBuilderS0V1<O, V0> implements Opcodes{
  private MethodVisitor mv;
  private ClassBuilder cb;
  
  public MethodBuilderS0V1(ClassBuilder cb, MethodVisitor mv) {
  	this.cb = cb;
    this.mv = mv;
    mv.visitCode();    
  }
  
  public ClassBuilder endMethod() {
  	mv.visitMaxs(0, 0);
    mv.visitEnd();
    
  	return cb;
  }
  
  // CONSTRUCTION
  
    public <S> MethodBuilderS1V1<O, S, V0> newInstance
  (Class<S> type) {
    mv.visitTypeInsn(NEW, type.getName().replace('.', '/'));
    return new MethodBuilderS1V1<O, S, V0>(cb, mv);
  }
    
    public <S> MethodBuilderS1V1<O, S, V0> newArray(Class<S> type) {
    mv.visitTypeInsn(ANEWARRAY, type.getName().replace('.', '/'));
    return new MethodBuilderS1V1<O, S, V0>(cb, mv);
  }
    
  // STACK MANIPULATION
  
    public <S> MethodBuilderS1V1<O, S, V0> assumePush(Class<S> type) {
    return new MethodBuilderS1V1<O, S, V0>(cb, mv);
  }
    
    
  
    public <S> MethodBuilderS1V1<O, S, V0> push(S value) {
    mv.visitLdcInsn(value);
    return new MethodBuilderS1V1<O, S, V0>(cb, mv);
  }
    
    
    
  // METHODS

    public InvokeBuilderS0V1<O, V0> invoke() {
    return new InvokeBuilderS0V1<O, V0>(new Type[] {}, cb, mv);
  }


    
  public static class InvokeBuilderS0V1<O, V0> {
    private final ClassBuilder cb;
    private final MethodVisitor mv;
    private final Type[] args;
    
    InvokeBuilderS0V1(Type[] args, ClassBuilder cb, MethodVisitor mv) {
      this.args = args;
      this.mv = mv;
      this.cb = cb;
    }
    
        
        
    
        
          
    
        
     
    
        public <S> MethodBuilderS1V1<O, S, V0> stat(Class owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS1V1<O, S, V0>(cb, mv);
    }
        

           public MethodBuilderS0V1<O, V0> statVoid(Class owner, String name) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS0V1<O, V0>(cb, mv);
    }        

    
      }
  
  
  // FIELDS
  
    
  public <S> MethodBuilderS1V1<O, S, V0> getStatic(Class owner, String name, Class<S> type) {
    mv.visitFieldInsn(GETSTATIC, owner.getName().replace('.', '/'), name, Type.getDescriptor(type));
    return new MethodBuilderS1V1<O, S, V0>(cb, mv);
  }
    
  // ARRAYS
  
    
  
  // VARIABLES
  
  	  	  public <V> MethodBuilderS0V1<O, V> assumeVar0(Class<V> type) {
	    return new MethodBuilderS0V1<O, V>(cb, mv);
	  }
	    	
  	
  	  	  	  	
	  	  public MethodBuilderS1V1<O, V0, V0> loadVar0(Class<V0> type) {
	    mv.visitVarInsn(ALOAD, 0);
	    return new MethodBuilderS1V1<O, V0, V0>(cb, mv);
	  }
	  	  	  	  
	    	  	  public <V> MethodBuilderS0V2<O, V0, V> assumeVar1(Class<V> type) {
	    return new MethodBuilderS0V2<O, V0, V>(cb, mv);
	  }  		  	
	    	
  	
  	  	  	  	
	  	  	  	  
	      
  // FLOW CONTROL
  
    public MethodBuilderS0V1<O, V0> returnVoid() {
    mv.visitInsn(RETURN);
    return new MethodBuilderS0V1<O, V0>(cb, mv);
  }  
  
    
    
  public MethodBuilderS0V1<O, V0> goTo(Label label) {
    mv.visitJumpInsn(GOTO, label);
    return new MethodBuilderS0V1<O, V0>(cb, mv);
  }
  
  // SUPPORT
  
    public MethodBuilderS0V0<O> reset() {
    return new MethodBuilderS0V0<O>(cb, mv);
  }
  
    public MethodBuilderS0V1<O, V0> resetStack() {
    return new MethodBuilderS0V1<O, V0>(cb, mv);
  }     
  
   
  public MethodBuilderS0V1<O, V0> closure(Closure closure) {
  	closure.apply(this.reset());
  	return this;
  }
  
   
  public MethodBuilderS0V1<O, V0> closure(ClosureS0V1 closure) {
  	closure.apply(this);
  	return this;
  }
  
   
  interface ClosureS0V1 {
  	<O, V0> void apply(MethodBuilderS0V1<O, V0> mb);
  }
}