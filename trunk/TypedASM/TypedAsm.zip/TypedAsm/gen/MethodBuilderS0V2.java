
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

public class MethodBuilderS0V2<O, V0, V1> implements Opcodes{
  private MethodVisitor mv;
  private ClassBuilder cb;
  
  public MethodBuilderS0V2(ClassBuilder cb, MethodVisitor mv) {
  	this.cb = cb;
    this.mv = mv;
    mv.visitCode();    
  }
  
  public ClassBuilder endMethod() {
  	mv.visitMaxs(0, 0);
    mv.visitEnd();
    
  	return cb;
  }
  
  // CONSTRUCTION
  
    public <S> MethodBuilderS1V2<O, S, V0, V1> newInstance
  (Class<S> type) {
    mv.visitTypeInsn(NEW, type.getName().replace('.', '/'));
    return new MethodBuilderS1V2<O, S, V0, V1>(cb, mv);
  }
    
    public <S> MethodBuilderS1V2<O, S, V0, V1> newArray(Class<S> type) {
    mv.visitTypeInsn(ANEWARRAY, type.getName().replace('.', '/'));
    return new MethodBuilderS1V2<O, S, V0, V1>(cb, mv);
  }
    
  // STACK MANIPULATION
  
    public <S> MethodBuilderS1V2<O, S, V0, V1> assumePush(Class<S> type) {
    return new MethodBuilderS1V2<O, S, V0, V1>(cb, mv);
  }
    
    
  
    public <S> MethodBuilderS1V2<O, S, V0, V1> push(S value) {
    mv.visitLdcInsn(value);
    return new MethodBuilderS1V2<O, S, V0, V1>(cb, mv);
  }
    
    
    
  // METHODS

    public InvokeBuilderS0V2<O, V0, V1> invoke() {
    return new InvokeBuilderS0V2<O, V0, V1>(new Type[] {}, cb, mv);
  }


    
  public static class InvokeBuilderS0V2<O, V0, V1> {
    private final ClassBuilder cb;
    private final MethodVisitor mv;
    private final Type[] args;
    
    InvokeBuilderS0V2(Type[] args, ClassBuilder cb, MethodVisitor mv) {
      this.args = args;
      this.mv = mv;
      this.cb = cb;
    }
    
        
        
    
        
          
    
        
     
    
        public <S> MethodBuilderS1V2<O, S, V0, V1> stat(Class owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS1V2<O, S, V0, V1>(cb, mv);
    }
        

           public MethodBuilderS0V2<O, V0, V1> statVoid(Class owner, String name) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS0V2<O, V0, V1>(cb, mv);
    }        

    
      }
  
  
  // FIELDS
  
    
  public <S> MethodBuilderS1V2<O, S, V0, V1> getStatic(Class owner, String name, Class<S> type) {
    mv.visitFieldInsn(GETSTATIC, owner.getName().replace('.', '/'), name, Type.getDescriptor(type));
    return new MethodBuilderS1V2<O, S, V0, V1>(cb, mv);
  }
    
  // ARRAYS
  
    
  
  // VARIABLES
  
  	  	  public <V> MethodBuilderS0V2<O, V, V1> assumeVar0(Class<V> type) {
	    return new MethodBuilderS0V2<O, V, V1>(cb, mv);
	  }
	    	
  	
  	  	  	  	
	  	  public MethodBuilderS1V2<O, V0, V0, V1> loadVar0(Class<V0> type) {
	    mv.visitVarInsn(ALOAD, 0);
	    return new MethodBuilderS1V2<O, V0, V0, V1>(cb, mv);
	  }
	  	  	  	  
	    	  	  public <V> MethodBuilderS0V2<O, V0, V> assumeVar1(Class<V> type) {
	    return new MethodBuilderS0V2<O, V0, V>(cb, mv);
	  }
	    	
  	
  	  	  	  	
	  	  public MethodBuilderS1V2<O, V1, V0, V1> loadVar1(Class<V1> type) {
	    mv.visitVarInsn(ALOAD, 1);
	    return new MethodBuilderS1V2<O, V1, V0, V1>(cb, mv);
	  }
	  	  	  	  
	    	  	  public <V> MethodBuilderS0V3<O, V0, V1, V> assumeVar2(Class<V> type) {
	    return new MethodBuilderS0V3<O, V0, V1, V>(cb, mv);
	  }  		  	
	    	
  	
  	  	  	  	
	  	  	  	  
	      
  // FLOW CONTROL
  
    public MethodBuilderS0V2<O, V0, V1> returnVoid() {
    mv.visitInsn(RETURN);
    return new MethodBuilderS0V2<O, V0, V1>(cb, mv);
  }  
  
    
    
  public MethodBuilderS0V2<O, V0, V1> goTo(Label label) {
    mv.visitJumpInsn(GOTO, label);
    return new MethodBuilderS0V2<O, V0, V1>(cb, mv);
  }
  
  // SUPPORT
  
    public MethodBuilderS0V0<O> reset() {
    return new MethodBuilderS0V0<O>(cb, mv);
  }
  
    public MethodBuilderS0V2<O, V0, V1> resetStack() {
    return new MethodBuilderS0V2<O, V0, V1>(cb, mv);
  }     
  
   
  public MethodBuilderS0V2<O, V0, V1> closure(Closure closure) {
  	closure.apply(this.reset());
  	return this;
  }
  
   
  public MethodBuilderS0V2<O, V0, V1> closure(ClosureS0V2 closure) {
  	closure.apply(this);
  	return this;
  }
  
   
  interface ClosureS0V2 {
  	<O, V0, V1> void apply(MethodBuilderS0V2<O, V0, V1> mb);
  }
}