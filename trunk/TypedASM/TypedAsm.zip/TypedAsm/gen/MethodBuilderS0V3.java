
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

public class MethodBuilderS0V3<O, V0, V1, V2> implements Opcodes{
  private MethodVisitor mv;
  private ClassBuilder cb;
  
  public MethodBuilderS0V3(ClassBuilder cb, MethodVisitor mv) {
  	this.cb = cb;
    this.mv = mv;
    mv.visitCode();    
  }
  
  public ClassBuilder endMethod() {
  	mv.visitMaxs(0, 0);
    mv.visitEnd();
    
  	return cb;
  }
  
  // CONSTRUCTION
  
    public <S> MethodBuilderS1V3<O, S, V0, V1, V2> newInstance
  (Class<S> type) {
    mv.visitTypeInsn(NEW, type.getName().replace('.', '/'));
    return new MethodBuilderS1V3<O, S, V0, V1, V2>(cb, mv);
  }
    
    public <S> MethodBuilderS1V3<O, S, V0, V1, V2> newArray(Class<S> type) {
    mv.visitTypeInsn(ANEWARRAY, type.getName().replace('.', '/'));
    return new MethodBuilderS1V3<O, S, V0, V1, V2>(cb, mv);
  }
    
  // STACK MANIPULATION
  
    public <S> MethodBuilderS1V3<O, S, V0, V1, V2> assumePush(Class<S> type) {
    return new MethodBuilderS1V3<O, S, V0, V1, V2>(cb, mv);
  }
    
    
  
    public <S> MethodBuilderS1V3<O, S, V0, V1, V2> push(S value) {
    mv.visitLdcInsn(value);
    return new MethodBuilderS1V3<O, S, V0, V1, V2>(cb, mv);
  }
    
    
    
  // METHODS

    public InvokeBuilderS0V3<O, V0, V1, V2> invoke() {
    return new InvokeBuilderS0V3<O, V0, V1, V2>(new Type[] {}, cb, mv);
  }


    
  public static class InvokeBuilderS0V3<O, V0, V1, V2> {
    private final ClassBuilder cb;
    private final MethodVisitor mv;
    private final Type[] args;
    
    InvokeBuilderS0V3(Type[] args, ClassBuilder cb, MethodVisitor mv) {
      this.args = args;
      this.mv = mv;
      this.cb = cb;
    }
    
        
        
    
        
          
    
        
     
    
        public <S> MethodBuilderS1V3<O, S, V0, V1, V2> stat(Class owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS1V3<O, S, V0, V1, V2>(cb, mv);
    }
        

           public MethodBuilderS0V3<O, V0, V1, V2> statVoid(Class owner, String name) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS0V3<O, V0, V1, V2>(cb, mv);
    }        

    
      }
  
  
  // FIELDS
  
    
  public <S> MethodBuilderS1V3<O, S, V0, V1, V2> getStatic(Class owner, String name, Class<S> type) {
    mv.visitFieldInsn(GETSTATIC, owner.getName().replace('.', '/'), name, Type.getDescriptor(type));
    return new MethodBuilderS1V3<O, S, V0, V1, V2>(cb, mv);
  }
    
  // ARRAYS
  
    
  
  // VARIABLES
  
  	  	  public <V> MethodBuilderS0V3<O, V, V1, V2> assumeVar0(Class<V> type) {
	    return new MethodBuilderS0V3<O, V, V1, V2>(cb, mv);
	  }
	    	
  	
  	  	  	  	
	  	  public MethodBuilderS1V3<O, V0, V0, V1, V2> loadVar0(Class<V0> type) {
	    mv.visitVarInsn(ALOAD, 0);
	    return new MethodBuilderS1V3<O, V0, V0, V1, V2>(cb, mv);
	  }
	  	  	  	  
	    	  	  public <V> MethodBuilderS0V3<O, V0, V, V2> assumeVar1(Class<V> type) {
	    return new MethodBuilderS0V3<O, V0, V, V2>(cb, mv);
	  }
	    	
  	
  	  	  	  	
	  	  public MethodBuilderS1V3<O, V1, V0, V1, V2> loadVar1(Class<V1> type) {
	    mv.visitVarInsn(ALOAD, 1);
	    return new MethodBuilderS1V3<O, V1, V0, V1, V2>(cb, mv);
	  }
	  	  	  	  
	    	  	  public <V> MethodBuilderS0V3<O, V0, V1, V> assumeVar2(Class<V> type) {
	    return new MethodBuilderS0V3<O, V0, V1, V>(cb, mv);
	  }
	    	
  	
  	  	  	  	
	  	  public MethodBuilderS1V3<O, V2, V0, V1, V2> loadVar2(Class<V2> type) {
	    mv.visitVarInsn(ALOAD, 2);
	    return new MethodBuilderS1V3<O, V2, V0, V1, V2>(cb, mv);
	  }
	  	  	  	  
	    	    	
  	
  	  	  	  	
	  	  	  	  
	      
  // FLOW CONTROL
  
    public MethodBuilderS0V3<O, V0, V1, V2> returnVoid() {
    mv.visitInsn(RETURN);
    return new MethodBuilderS0V3<O, V0, V1, V2>(cb, mv);
  }  
  
    
    
  public MethodBuilderS0V3<O, V0, V1, V2> goTo(Label label) {
    mv.visitJumpInsn(GOTO, label);
    return new MethodBuilderS0V3<O, V0, V1, V2>(cb, mv);
  }
  
  // SUPPORT
  
    public MethodBuilderS0V0<O> reset() {
    return new MethodBuilderS0V0<O>(cb, mv);
  }
  
    public MethodBuilderS0V3<O, V0, V1, V2> resetStack() {
    return new MethodBuilderS0V3<O, V0, V1, V2>(cb, mv);
  }     
  
   
  public MethodBuilderS0V3<O, V0, V1, V2> closure(Closure closure) {
  	closure.apply(this.reset());
  	return this;
  }
  
   
  public MethodBuilderS0V3<O, V0, V1, V2> closure(ClosureS0V3 closure) {
  	closure.apply(this);
  	return this;
  }
  
   
  interface ClosureS0V3 {
  	<O, V0, V1, V2> void apply(MethodBuilderS0V3<O, V0, V1, V2> mb);
  }
}