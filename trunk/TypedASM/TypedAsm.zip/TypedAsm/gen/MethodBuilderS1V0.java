
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

public class MethodBuilderS1V0<O, S0> implements Opcodes{
  private MethodVisitor mv;
  private ClassBuilder cb;
  
  public MethodBuilderS1V0(ClassBuilder cb, MethodVisitor mv) {
  	this.cb = cb;
    this.mv = mv;
    mv.visitCode();    
  }
  
  public ClassBuilder endMethod() {
  	mv.visitMaxs(0, 0);
    mv.visitEnd();
    
  	return cb;
  }
  
  // CONSTRUCTION
  
    public <S> MethodBuilderS2V0<O, S0, S> newInstance
  (Class<S> type) {
    mv.visitTypeInsn(NEW, type.getName().replace('.', '/'));
    return new MethodBuilderS2V0<O, S0, S>(cb, mv);
  }
    
    public <S> MethodBuilderS2V0<O, S0, S> newArray(Class<S> type) {
    mv.visitTypeInsn(ANEWARRAY, type.getName().replace('.', '/'));
    return new MethodBuilderS2V0<O, S0, S>(cb, mv);
  }
    
  // STACK MANIPULATION
  
    public <S> MethodBuilderS2V0<O, S0, S> assumePush(Class<S> type) {
    return new MethodBuilderS2V0<O, S0, S>(cb, mv);
  }
    
    public MethodBuilderS0V0<O> assumePop() {
    return new MethodBuilderS0V0<O>(cb, mv);
  }
    
  
    public <S> MethodBuilderS2V0<O, S0, S> push(S value) {
    mv.visitLdcInsn(value);
    return new MethodBuilderS2V0<O, S0, S>(cb, mv);
  }
    
    public MethodBuilderS0V0<O> pop() {
    mv.visitInsn(POP);
    return new MethodBuilderS0V0<O>(cb, mv);
  }
    
    
  public MethodBuilderS2V0<O, S0, S0>  dup() {
    mv.visitInsn(DUP);
    return new MethodBuilderS2V0<O, S0, S0>(cb, mv);
  }
    
  // METHODS

    public InvokeBuilderS1V0<O, S0> invoke() {
    return new InvokeBuilderS1V0<O, S0>(new Type[] {}, cb, mv);
  }


    
  public static class InvokeBuilderS1V0<O, S0> {
    private final ClassBuilder cb;
    private final MethodVisitor mv;
    private final Type[] args;
    
    InvokeBuilderS1V0(Type[] args, ClassBuilder cb, MethodVisitor mv) {
      this.args = args;
      this.mv = mv;
      this.cb = cb;
    }
    
        public <S> MethodBuilderS1V0<O, S> virt(Class < ? super S0> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKEVIRTUAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS1V0<O, S>(cb, mv);
    }
        
        public MethodBuilderS0V0<O> virtVoid(Class < ? super S0> owner, String name) {
      mv.visitMethodInsn(INVOKEVIRTUAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS0V0<O>(cb, mv);
    }
        
    
        public <S> MethodBuilderS1V0<O, S> spec(Class < ? super S0> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKESPECIAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS1V0<O, S>(cb, mv);
    }
        
        public MethodBuilderS0V0<O> specVoid(Class < ? super S0> owner, String name) {
      mv.visitMethodInsn(INVOKESPECIAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS0V0<O>(cb, mv);
    }
          
    
        public <S> MethodBuilderS1V0<O, S> iface(Class < ? super S0> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKEINTERFACE, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS1V0<O, S>(cb, mv);
    }
        
        public MethodBuilderS0V0<O> ifaceVoid(Class < ? super S0> owner, String name) {
      mv.visitMethodInsn(INVOKEINTERFACE, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS0V0<O>(cb, mv);
    }
     
    
        public <S> MethodBuilderS2V0<O, S0, S> stat(Class owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS2V0<O, S0, S>(cb, mv);
    }
        

           public MethodBuilderS1V0<O, S0> statVoid(Class owner, String name) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS1V0<O, S0>(cb, mv);
    }        

    
        public MethodBuilderS0V0.InvokeBuilderS0V0<O> param(Class< ? super S0> type) {
      Type[] newArgs = new Type[args.length + 1];
      newArgs[newArgs.length - 1] = Type.getType(type);
      System.arraycopy(args, 0, newArgs, 0, args.length);
      return new MethodBuilderS0V0.InvokeBuilderS0V0<O>(newArgs, cb, mv);
    }
      }
  
  
  // FIELDS
  
    
  public <S> MethodBuilderS2V0<O, S0, S> getStatic(Class owner, String name, Class<S> type) {
    mv.visitFieldInsn(GETSTATIC, owner.getName().replace('.', '/'), name, Type.getDescriptor(type));
    return new MethodBuilderS2V0<O, S0, S>(cb, mv);
  }
    
  // ARRAYS
  
    
  
  // VARIABLES
  
  	  	  public <V> MethodBuilderS1V1<O, S0, V> assumeVar0(Class<V> type) {
	    return new MethodBuilderS1V1<O, S0, V>(cb, mv);
	  }  		  	
	    	
  	
  	  	  	  	
	  	  	  	  
	  	  public MethodBuilderS1V1<O, S0, S0> storeVar0(Class<S0> type) {
	    mv.visitVarInsn(ASTORE, 0);
	    return new MethodBuilderS1V1<O, S0, S0>(cb, mv);
	  }  	
	      
  // FLOW CONTROL
  
    public MethodBuilderS0V0<O> returnVoid() {
    mv.visitInsn(RETURN);
    return new MethodBuilderS0V0<O>(cb, mv);
  }  
  
    public MethodBuilderS0V0<O> returnValue(Class<S0> type) {
    mv.visitInsn(ARETURN);
    return new MethodBuilderS0V0<O>(cb, mv);
  }
    
    
  public MethodBuilderS1V0<O, S0> goTo(Label label) {
    mv.visitJumpInsn(GOTO, label);
    return new MethodBuilderS1V0<O, S0>(cb, mv);
  }
  
  // SUPPORT
  
    public MethodBuilderS0V0<O> reset() {
    return new MethodBuilderS0V0<O>(cb, mv);
  }
  
    public MethodBuilderS0V0<O> resetStack() {
    return new MethodBuilderS0V0<O>(cb, mv);
  }     
  
   
  public MethodBuilderS1V0<O, S0> closure(Closure closure) {
  	closure.apply(this.reset());
  	return this;
  }
  
   
  public MethodBuilderS1V0<O, S0> closure(ClosureS1V0 closure) {
  	closure.apply(this);
  	return this;
  }
  
   
  interface ClosureS1V0 {
  	<O, S0> void apply(MethodBuilderS1V0<O, S0> mb);
  }
}