
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

public class MethodBuilderS2V0<O, S0, S1> implements Opcodes{
  private MethodVisitor mv;
  private ClassBuilder cb;
  
  public MethodBuilderS2V0(ClassBuilder cb, MethodVisitor mv) {
  	this.cb = cb;
    this.mv = mv;
    mv.visitCode();    
  }
  
  public ClassBuilder endMethod() {
  	mv.visitMaxs(0, 0);
    mv.visitEnd();
    
  	return cb;
  }
  
  // CONSTRUCTION
  
    public <S> MethodBuilderS3V0<O, S0, S1, S> newInstance
  (Class<S> type) {
    mv.visitTypeInsn(NEW, type.getName().replace('.', '/'));
    return new MethodBuilderS3V0<O, S0, S1, S>(cb, mv);
  }
    
    public <S> MethodBuilderS3V0<O, S0, S1, S> newArray(Class<S> type) {
    mv.visitTypeInsn(ANEWARRAY, type.getName().replace('.', '/'));
    return new MethodBuilderS3V0<O, S0, S1, S>(cb, mv);
  }
    
  // STACK MANIPULATION
  
    public <S> MethodBuilderS3V0<O, S0, S1, S> assumePush(Class<S> type) {
    return new MethodBuilderS3V0<O, S0, S1, S>(cb, mv);
  }
    
    public MethodBuilderS1V0<O, S0> assumePop() {
    return new MethodBuilderS1V0<O, S0>(cb, mv);
  }
    
  
    public <S> MethodBuilderS3V0<O, S0, S1, S> push(S value) {
    mv.visitLdcInsn(value);
    return new MethodBuilderS3V0<O, S0, S1, S>(cb, mv);
  }
    
    public MethodBuilderS1V0<O, S0> pop() {
    mv.visitInsn(POP);
    return new MethodBuilderS1V0<O, S0>(cb, mv);
  }
    
    
  public MethodBuilderS3V0<O, S0, S1, S1>  dup() {
    mv.visitInsn(DUP);
    return new MethodBuilderS3V0<O, S0, S1, S1>(cb, mv);
  }
    
  // METHODS

    public InvokeBuilderS2V0<O, S0, S1> invoke() {
    return new InvokeBuilderS2V0<O, S0, S1>(new Type[] {}, cb, mv);
  }


    
  public static class InvokeBuilderS2V0<O, S0, S1> {
    private final ClassBuilder cb;
    private final MethodVisitor mv;
    private final Type[] args;
    
    InvokeBuilderS2V0(Type[] args, ClassBuilder cb, MethodVisitor mv) {
      this.args = args;
      this.mv = mv;
      this.cb = cb;
    }
    
        public <S> MethodBuilderS2V0<O, S0, S> virt(Class < ? super S1> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKEVIRTUAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS2V0<O, S0, S>(cb, mv);
    }
        
        public MethodBuilderS1V0<O, S0> virtVoid(Class < ? super S1> owner, String name) {
      mv.visitMethodInsn(INVOKEVIRTUAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS1V0<O, S0>(cb, mv);
    }
        
    
        public <S> MethodBuilderS2V0<O, S0, S> spec(Class < ? super S1> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKESPECIAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS2V0<O, S0, S>(cb, mv);
    }
        
        public MethodBuilderS1V0<O, S0> specVoid(Class < ? super S1> owner, String name) {
      mv.visitMethodInsn(INVOKESPECIAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS1V0<O, S0>(cb, mv);
    }
          
    
        public <S> MethodBuilderS2V0<O, S0, S> iface(Class < ? super S1> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKEINTERFACE, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS2V0<O, S0, S>(cb, mv);
    }
        
        public MethodBuilderS1V0<O, S0> ifaceVoid(Class < ? super S1> owner, String name) {
      mv.visitMethodInsn(INVOKEINTERFACE, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS1V0<O, S0>(cb, mv);
    }
     
    
        public <S> MethodBuilderS3V0<O, S0, S1, S> stat(Class owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS3V0<O, S0, S1, S>(cb, mv);
    }
        

           public MethodBuilderS2V0<O, S0, S1> statVoid(Class owner, String name) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS2V0<O, S0, S1>(cb, mv);
    }        

    
        public MethodBuilderS1V0.InvokeBuilderS1V0<O, S0> param(Class< ? super S1> type) {
      Type[] newArgs = new Type[args.length + 1];
      newArgs[newArgs.length - 1] = Type.getType(type);
      System.arraycopy(args, 0, newArgs, 0, args.length);
      return new MethodBuilderS1V0.InvokeBuilderS1V0<O, S0>(newArgs, cb, mv);
    }
      }
  
  
  // FIELDS
  
    
  public <S> MethodBuilderS3V0<O, S0, S1, S> getStatic(Class owner, String name, Class<S> type) {
    mv.visitFieldInsn(GETSTATIC, owner.getName().replace('.', '/'), name, Type.getDescriptor(type));
    return new MethodBuilderS3V0<O, S0, S1, S>(cb, mv);
  }
    
  // ARRAYS
  
    public <S> MethodBuilderS1V0<O, S> arrayLoad(Class<S0> target, Class<S1> index, Class<S> result) {
    mv.visitInsn(AALOAD);
    
    return new MethodBuilderS1V0<O, S>(cb, mv);
  }
    
  
  // VARIABLES
  
  	  	  public <V> MethodBuilderS2V1<O, S0, S1, V> assumeVar0(Class<V> type) {
	    return new MethodBuilderS2V1<O, S0, S1, V>(cb, mv);
	  }  		  	
	    	
  	
  	  	  	  	
	  	  	  	  
	  	  public MethodBuilderS2V1<O, S0, S1, S1> storeVar0(Class<S1> type) {
	    mv.visitVarInsn(ASTORE, 0);
	    return new MethodBuilderS2V1<O, S0, S1, S1>(cb, mv);
	  }  	
	      
  // FLOW CONTROL
  
    public MethodBuilderS0V0<O> returnVoid() {
    mv.visitInsn(RETURN);
    return new MethodBuilderS0V0<O>(cb, mv);
  }  
  
    public MethodBuilderS0V0<O> returnValue(Class<S1> type) {
    mv.visitInsn(ARETURN);
    return new MethodBuilderS0V0<O>(cb, mv);
  }
    
    
  public MethodBuilderS2V0<O, S0, S1> goTo(Label label) {
    mv.visitJumpInsn(GOTO, label);
    return new MethodBuilderS2V0<O, S0, S1>(cb, mv);
  }
  
  // SUPPORT
  
    public MethodBuilderS0V0<O> reset() {
    return new MethodBuilderS0V0<O>(cb, mv);
  }
  
    public MethodBuilderS0V0<O> resetStack() {
    return new MethodBuilderS0V0<O>(cb, mv);
  }     
  
   
  public MethodBuilderS2V0<O, S0, S1> closure(Closure closure) {
  	closure.apply(this.reset());
  	return this;
  }
  
   
  public MethodBuilderS2V0<O, S0, S1> closure(ClosureS2V0 closure) {
  	closure.apply(this);
  	return this;
  }
  
   
  interface ClosureS2V0 {
  	<O, S0, S1> void apply(MethodBuilderS2V0<O, S0, S1> mb);
  }
}