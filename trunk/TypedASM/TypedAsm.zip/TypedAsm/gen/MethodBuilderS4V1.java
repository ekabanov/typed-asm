
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

public class MethodBuilderS4V1<O, S0, S1, S2, S3, V0> implements Opcodes{
  private MethodVisitor mv;
  private ClassBuilder cb;
  
  public MethodBuilderS4V1(ClassBuilder cb, MethodVisitor mv) {
  	this.cb = cb;
    this.mv = mv;
    mv.visitCode();    
  }
  
  public ClassBuilder endMethod() {
  	mv.visitMaxs(0, 0);
    mv.visitEnd();
    
  	return cb;
  }
  
  // CONSTRUCTION
  
    
    
  // STACK MANIPULATION
  
    
    public MethodBuilderS3V1<O, S0, S1, S2, V0> assumePop() {
    return new MethodBuilderS3V1<O, S0, S1, S2, V0>(cb, mv);
  }
    
  
    
    public MethodBuilderS3V1<O, S0, S1, S2, V0> pop() {
    mv.visitInsn(POP);
    return new MethodBuilderS3V1<O, S0, S1, S2, V0>(cb, mv);
  }
    
    
  // METHODS

    public InvokeBuilderS4V1<O, S0, S1, S2, S3, V0> invoke() {
    return new InvokeBuilderS4V1<O, S0, S1, S2, S3, V0>(new Type[] {}, cb, mv);
  }


    
  public static class InvokeBuilderS4V1<O, S0, S1, S2, S3, V0> {
    private final ClassBuilder cb;
    private final MethodVisitor mv;
    private final Type[] args;
    
    InvokeBuilderS4V1(Type[] args, ClassBuilder cb, MethodVisitor mv) {
      this.args = args;
      this.mv = mv;
      this.cb = cb;
    }
    
        public <S> MethodBuilderS4V1<O, S0, S1, S2, S, V0> virt(Class < ? super S3> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKEVIRTUAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS4V1<O, S0, S1, S2, S, V0>(cb, mv);
    }
        
        public MethodBuilderS3V1<O, S0, S1, S2, V0> virtVoid(Class < ? super S3> owner, String name) {
      mv.visitMethodInsn(INVOKEVIRTUAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS3V1<O, S0, S1, S2, V0>(cb, mv);
    }
        
    
        public <S> MethodBuilderS4V1<O, S0, S1, S2, S, V0> spec(Class < ? super S3> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKESPECIAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS4V1<O, S0, S1, S2, S, V0>(cb, mv);
    }
        
        public MethodBuilderS3V1<O, S0, S1, S2, V0> specVoid(Class < ? super S3> owner, String name) {
      mv.visitMethodInsn(INVOKESPECIAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS3V1<O, S0, S1, S2, V0>(cb, mv);
    }
          
    
        public <S> MethodBuilderS4V1<O, S0, S1, S2, S, V0> iface(Class < ? super S3> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKEINTERFACE, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS4V1<O, S0, S1, S2, S, V0>(cb, mv);
    }
        
        public MethodBuilderS3V1<O, S0, S1, S2, V0> ifaceVoid(Class < ? super S3> owner, String name) {
      mv.visitMethodInsn(INVOKEINTERFACE, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS3V1<O, S0, S1, S2, V0>(cb, mv);
    }
     
    
        

           public MethodBuilderS4V1<O, S0, S1, S2, S3, V0> statVoid(Class owner, String name) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS4V1<O, S0, S1, S2, S3, V0>(cb, mv);
    }        

    
        public MethodBuilderS3V1.InvokeBuilderS3V1<O, S0, S1, S2, V0> param(Class< ? super S3> type) {
      Type[] newArgs = new Type[args.length + 1];
      newArgs[newArgs.length - 1] = Type.getType(type);
      System.arraycopy(args, 0, newArgs, 0, args.length);
      return new MethodBuilderS3V1.InvokeBuilderS3V1<O, S0, S1, S2, V0>(newArgs, cb, mv);
    }
      }
  
  
  // FIELDS
  
    
  // ARRAYS
  
    public <S> MethodBuilderS3V1<O, S0, S1, S, V0> arrayLoad(Class<S2> target, Class<S3> index, Class<S> result) {
    mv.visitInsn(AALOAD);
    
    return new MethodBuilderS3V1<O, S0, S1, S, V0>(cb, mv);
  }
    
  
  // VARIABLES
  
  	  	  public <V> MethodBuilderS4V1<O, S0, S1, S2, S3, V> assumeVar0(Class<V> type) {
	    return new MethodBuilderS4V1<O, S0, S1, S2, S3, V>(cb, mv);
	  }
	    	
  	
  	  	  	  	
	  	  	  	  
	  	  public MethodBuilderS4V1<O, S0, S1, S2, S3, S3> storeVar0(Class<S3> type) {
	    mv.visitVarInsn(ASTORE, 0);
	    return new MethodBuilderS4V1<O, S0, S1, S2, S3, S3>(cb, mv);
	  }
	    	  	  public <V> MethodBuilderS4V2<O, S0, S1, S2, S3, V0, V> assumeVar1(Class<V> type) {
	    return new MethodBuilderS4V2<O, S0, S1, S2, S3, V0, V>(cb, mv);
	  }  		  	
	    	
  	
  	  	  	  	
	  	  	  	  
	  	  public MethodBuilderS4V2<O, S0, S1, S2, S3, V0, S3> storeVar1(Class<S3> type) {
	    mv.visitVarInsn(ASTORE, 1);
	    return new MethodBuilderS4V2<O, S0, S1, S2, S3, V0, S3>(cb, mv);
	  }  	
	      
  // FLOW CONTROL
  
    public MethodBuilderS0V1<O, V0> returnVoid() {
    mv.visitInsn(RETURN);
    return new MethodBuilderS0V1<O, V0>(cb, mv);
  }  
  
    public MethodBuilderS0V1<O, V0> returnValue(Class<S3> type) {
    mv.visitInsn(ARETURN);
    return new MethodBuilderS0V1<O, V0>(cb, mv);
  }
    
    
  public MethodBuilderS4V1<O, S0, S1, S2, S3, V0> goTo(Label label) {
    mv.visitJumpInsn(GOTO, label);
    return new MethodBuilderS4V1<O, S0, S1, S2, S3, V0>(cb, mv);
  }
  
  // SUPPORT
  
    public MethodBuilderS0V0<O> reset() {
    return new MethodBuilderS0V0<O>(cb, mv);
  }
  
    public MethodBuilderS0V1<O, V0> resetStack() {
    return new MethodBuilderS0V1<O, V0>(cb, mv);
  }     
  
   
  public MethodBuilderS4V1<O, S0, S1, S2, S3, V0> closure(Closure closure) {
  	closure.apply(this.reset());
  	return this;
  }
  
   
  public MethodBuilderS4V1<O, S0, S1, S2, S3, V0> closure(ClosureS4V1 closure) {
  	closure.apply(this);
  	return this;
  }
  
   
  interface ClosureS4V1 {
  	<O, S0, S1, S2, S3, V0> void apply(MethodBuilderS4V1<O, S0, S1, S2, S3, V0> mb);
  }
}