
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

public class MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2> implements Opcodes{
  private MethodVisitor mv;
  private ClassBuilder cb;
  
  public MethodBuilderS4V3(ClassBuilder cb, MethodVisitor mv) {
  	this.cb = cb;
    this.mv = mv;
    mv.visitCode();    
  }
  
  public ClassBuilder endMethod() {
  	mv.visitMaxs(0, 0);
    mv.visitEnd();
    
  	return cb;
  }
  
  // CONSTRUCTION
  
    
    
  // STACK MANIPULATION
  
    
    public MethodBuilderS3V3<O, S0, S1, S2, V0, V1, V2> assumePop() {
    return new MethodBuilderS3V3<O, S0, S1, S2, V0, V1, V2>(cb, mv);
  }
    
  
    
    public MethodBuilderS3V3<O, S0, S1, S2, V0, V1, V2> pop() {
    mv.visitInsn(POP);
    return new MethodBuilderS3V3<O, S0, S1, S2, V0, V1, V2>(cb, mv);
  }
    
    
  // METHODS

    public InvokeBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2> invoke() {
    return new InvokeBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2>(new Type[] {}, cb, mv);
  }


    
  public static class InvokeBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2> {
    private final ClassBuilder cb;
    private final MethodVisitor mv;
    private final Type[] args;
    
    InvokeBuilderS4V3(Type[] args, ClassBuilder cb, MethodVisitor mv) {
      this.args = args;
      this.mv = mv;
      this.cb = cb;
    }
    
        public <S> MethodBuilderS4V3<O, S0, S1, S2, S, V0, V1, V2> virt(Class < ? super S3> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKEVIRTUAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS4V3<O, S0, S1, S2, S, V0, V1, V2>(cb, mv);
    }
        
        public MethodBuilderS3V3<O, S0, S1, S2, V0, V1, V2> virtVoid(Class < ? super S3> owner, String name) {
      mv.visitMethodInsn(INVOKEVIRTUAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS3V3<O, S0, S1, S2, V0, V1, V2>(cb, mv);
    }
        
    
        public <S> MethodBuilderS4V3<O, S0, S1, S2, S, V0, V1, V2> spec(Class < ? super S3> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKESPECIAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS4V3<O, S0, S1, S2, S, V0, V1, V2>(cb, mv);
    }
        
        public MethodBuilderS3V3<O, S0, S1, S2, V0, V1, V2> specVoid(Class < ? super S3> owner, String name) {
      mv.visitMethodInsn(INVOKESPECIAL, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS3V3<O, S0, S1, S2, V0, V1, V2>(cb, mv);
    }
          
    
        public <S> MethodBuilderS4V3<O, S0, S1, S2, S, V0, V1, V2> iface(Class < ? super S3> owner, String name, Class<S> type) {
      mv.visitMethodInsn(INVOKEINTERFACE, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.getType(type), args));
      return new MethodBuilderS4V3<O, S0, S1, S2, S, V0, V1, V2>(cb, mv);
    }
        
        public MethodBuilderS3V3<O, S0, S1, S2, V0, V1, V2> ifaceVoid(Class < ? super S3> owner, String name) {
      mv.visitMethodInsn(INVOKEINTERFACE, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS3V3<O, S0, S1, S2, V0, V1, V2>(cb, mv);
    }
     
    
        

           public MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2> statVoid(Class owner, String name) {
      mv.visitMethodInsn(INVOKESTATIC, Type.getInternalName(owner), name, Type.getMethodDescriptor(Type.VOID_TYPE, args));
      return new MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2>(cb, mv);
    }        

    
        public MethodBuilderS3V3.InvokeBuilderS3V3<O, S0, S1, S2, V0, V1, V2> param(Class< ? super S3> type) {
      Type[] newArgs = new Type[args.length + 1];
      newArgs[newArgs.length - 1] = Type.getType(type);
      System.arraycopy(args, 0, newArgs, 0, args.length);
      return new MethodBuilderS3V3.InvokeBuilderS3V3<O, S0, S1, S2, V0, V1, V2>(newArgs, cb, mv);
    }
      }
  
  
  // FIELDS
  
    
  // ARRAYS
  
    public <S> MethodBuilderS3V3<O, S0, S1, S, V0, V1, V2> arrayLoad(Class<S2> target, Class<S3> index, Class<S> result) {
    mv.visitInsn(AALOAD);
    
    return new MethodBuilderS3V3<O, S0, S1, S, V0, V1, V2>(cb, mv);
  }
    
  
  // VARIABLES
  
  	  	  public <V> MethodBuilderS4V3<O, S0, S1, S2, S3, V, V1, V2> assumeVar0(Class<V> type) {
	    return new MethodBuilderS4V3<O, S0, S1, S2, S3, V, V1, V2>(cb, mv);
	  }
	    	
  	
  	  	  	  	
	  	  	  	  
	  	  public MethodBuilderS4V3<O, S0, S1, S2, S3, S3, V1, V2> storeVar0(Class<S3> type) {
	    mv.visitVarInsn(ASTORE, 0);
	    return new MethodBuilderS4V3<O, S0, S1, S2, S3, S3, V1, V2>(cb, mv);
	  }
	    	  	  public <V> MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V, V2> assumeVar1(Class<V> type) {
	    return new MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V, V2>(cb, mv);
	  }
	    	
  	
  	  	  	  	
	  	  	  	  
	  	  public MethodBuilderS4V3<O, S0, S1, S2, S3, V0, S3, V2> storeVar1(Class<S3> type) {
	    mv.visitVarInsn(ASTORE, 1);
	    return new MethodBuilderS4V3<O, S0, S1, S2, S3, V0, S3, V2>(cb, mv);
	  }
	    	  	  public <V> MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V> assumeVar2(Class<V> type) {
	    return new MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V>(cb, mv);
	  }
	    	
  	
  	  	  	  	
	  	  	  	  
	  	  public MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, S3> storeVar2(Class<S3> type) {
	    mv.visitVarInsn(ASTORE, 2);
	    return new MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, S3>(cb, mv);
	  }
	    	    	
  	
  	  	  	  	
	  	  	  	  
	      
  // FLOW CONTROL
  
    public MethodBuilderS0V3<O, V0, V1, V2> returnVoid() {
    mv.visitInsn(RETURN);
    return new MethodBuilderS0V3<O, V0, V1, V2>(cb, mv);
  }  
  
    public MethodBuilderS0V3<O, V0, V1, V2> returnValue(Class<S3> type) {
    mv.visitInsn(ARETURN);
    return new MethodBuilderS0V3<O, V0, V1, V2>(cb, mv);
  }
    
    
  public MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2> goTo(Label label) {
    mv.visitJumpInsn(GOTO, label);
    return new MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2>(cb, mv);
  }
  
  // SUPPORT
  
    public MethodBuilderS0V0<O> reset() {
    return new MethodBuilderS0V0<O>(cb, mv);
  }
  
    public MethodBuilderS0V3<O, V0, V1, V2> resetStack() {
    return new MethodBuilderS0V3<O, V0, V1, V2>(cb, mv);
  }     
  
   
  public MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2> closure(Closure closure) {
  	closure.apply(this.reset());
  	return this;
  }
  
   
  public MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2> closure(ClosureS4V3 closure) {
  	closure.apply(this);
  	return this;
  }
  
   
  interface ClosureS4V3 {
  	<O, S0, S1, S2, S3, V0, V1, V2> void apply(MethodBuilderS4V3<O, S0, S1, S2, S3, V0, V1, V2> mb);
  }
}