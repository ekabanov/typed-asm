
public interface Closure {
  public <O> void apply(MethodBuilderS0V0<O> mb);
}
